npm install is required.
node-modules is not included.
node index.js in backend
npm run build in frontend (not npm run server-CORS issue)