module.exports = {
  transpileDependencies: [
    'vuetify'
  ],
  outputDir: '../backend/public'
};